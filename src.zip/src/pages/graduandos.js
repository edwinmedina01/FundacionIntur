import GraduandoTable from '../components/GraduandoTable';
import Layout from '../components/Layout';
export default function GraduandosPage() {
  return (
    

<Layout>
<div>
  
      <GraduandoTable />
    </div>
</Layout>
  );
}
