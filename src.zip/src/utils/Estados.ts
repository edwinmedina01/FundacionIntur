export enum Usuarios_ESTADOS {
    ACTIVO = 1,
    SUSPENDIDO = 2,
    INACTIVO = 3,
    ELIMINADO = 4,
}
