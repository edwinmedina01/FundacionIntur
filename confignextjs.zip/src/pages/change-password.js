import ChangePassword from '../components/ChangePassword';

export default function ChangePasswordPage() {
  return <ChangePassword />;
}
