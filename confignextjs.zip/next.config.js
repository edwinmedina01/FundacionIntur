/** @type {import('next').NextConfig} */
const nextConfig = {
    reactStrictMode: true,
    experimental: {
        middlewarePrefetch: "strict", // 🔹 Esto es válido
    },
};

module.exports = nextConfig;
